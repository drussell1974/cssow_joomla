<?php
/**
 * @package     ContentBuilder
 * @author      Markus Bopp
 * @link        http://www.crosstec.de
 * @license     GNU/GPL
*/

defined('_JEXEC') or die('Restricted access');
?>
<?php echo JText::_('COM_CONTENTBUILDER_ABOUT_DESC'); ?> <a href="https://www.crosstec.org">Crosstec Solutions</a>