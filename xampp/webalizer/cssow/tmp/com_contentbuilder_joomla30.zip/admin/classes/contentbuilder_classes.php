<?php
/**
 * @package     ContentBuilder
 * @author      Markus Bopp
 * @link        http://www.crosstec.de
 * @license     GNU/GPL
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

// this is just a stub used to extend from in form element plugins
class CBFormElementAfterValidation {
    
    function onSaveRecord($record_id){
        
    }
    
    function onSaveArticle($article_id){
        
        
    }
    
}
